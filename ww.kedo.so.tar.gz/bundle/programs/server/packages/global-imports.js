/* Imports for global scope */

FlowRouter = Package['kadira:flow-router'].FlowRouter;
BlazeLayout = Package['kadira:blaze-layout'].BlazeLayout;
i18n = Package['anti:i18n'].i18n;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Spacebars = Package.spacebars.Spacebars;
Accounts = Package['accounts-base'].Accounts;
HTML = Package.htmljs.HTML;

