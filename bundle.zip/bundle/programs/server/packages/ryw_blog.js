(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var Accounts = Package['accounts-base'].Accounts;
var moment = Package['momentjs:moment'].moment;
var Roles = Package['alanning:roles'].Roles;
var FastRender = Package['meteorhacks:fast-render'].FastRender;
var SubsManager = Package['meteorhacks:subs-manager'].SubsManager;
var check = Package.check.check;
var Match = Package.check.Match;
var JsonRoutes = Package['simple:json-routes'].JsonRoutes;
var Iron = Package['iron:core'].Iron;
var FS = Package['cfs:base-package'].FS;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/lib/boot.coffee.js                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.Blog = {};                                                                                                    // 1
                                                                                                                   //
Blog.settings = {                                                                                                  // 1
  comments: {},                                                                                                    // 4
  language: {}                                                                                                     // 4
};                                                                                                                 //
                                                                                                                   //
Blog.config = function(appConfig) {                                                                                // 1
  var i, key, len, ref;                                                                                            // 9
  ref = ['comments', 'language'];                                                                                  // 9
  for (i = 0, len = ref.length; i < len; i++) {                                                                    // 9
    key = ref[i];                                                                                                  //
    if (appConfig[key]) {                                                                                          // 10
      this.settings[key] = _.extend(this.settings[key], appConfig[key]);                                           // 11
      delete appConfig[key];                                                                                       // 11
    }                                                                                                              //
  }                                                                                                                // 9
  return this.settings = _.extend(this.settings, appConfig);                                                       //
};                                                                                                                 // 7
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 22
  Blog.config({                                                                                                    // 23
    adminRole: null,                                                                                               // 24
    adminGroup: null,                                                                                              // 24
    authorRole: null,                                                                                              // 24
    authorGroup: null                                                                                              // 24
  });                                                                                                              //
}                                                                                                                  //
                                                                                                                   //
if (Meteor.isClient) {                                                                                             // 35
  Blog.config({                                                                                                    // 36
    title: '',                                                                                                     // 37
    blogIndexTemplate: null,                                                                                       // 37
    blogShowTemplate: null,                                                                                        // 37
    blogNotFoundTemplate: null,                                                                                    // 37
    blogAdminTemplate: null,                                                                                       // 37
    blogAdminEditTemplate: null,                                                                                   // 37
    blogLayoutTemplate: null,                                                                                      // 37
    pageSize: 20,                                                                                                  // 37
    excerptFunction: null,                                                                                         // 37
    syntaxHighlighting: false,                                                                                     // 37
    syntaxHighlightingTheme: 'github',                                                                             // 37
    cdnFontAwesome: true,                                                                                          // 37
    dateFormat: 'MMM Do, YYYY',                                                                                    // 37
    comments: {                                                                                                    // 37
      allowAnonymous: false,                                                                                       // 51
      useSideComments: false,                                                                                      // 51
      defaultImg: '/packages/blog/public/default-user.png',                                                        // 51
      userImg: 'avatar',                                                                                           // 51
      disqusShortname: null                                                                                        // 51
    },                                                                                                             //
    language: {                                                                                                    // 37
      blogEmpty: 'This blog is looking pretty empty...',                                                           // 57
      backToBlogIndex: 'Back to the Blog',                                                                         // 57
      loadMore: 'Load More',                                                                                       // 57
      tags: 'Tags',                                                                                                // 57
      slug: 'Slug',                                                                                                // 57
      metaDescription: 'Meta Description',                                                                         // 57
      body: 'Body',                                                                                                // 57
      showAsVisual: 'Visual',                                                                                      // 57
      showAsHtml: 'HTML',                                                                                          // 57
      save: 'Save',                                                                                                // 57
      cancel: 'Cancel',                                                                                            // 57
      "delete": 'Delete',                                                                                          // 57
      metaAuthorBy: 'By',                                                                                          // 57
      metaAuthorOn: 'on',                                                                                          // 57
      edit: 'Edit',                                                                                                // 57
      areYouSure: 'Are you sure?',                                                                                 // 57
      disqusPoweredBy: 'comments powered by',                                                                      // 57
      adminHeader: 'Blog Admin',                                                                                   // 57
      addPost: 'Add Blog Post',                                                                                    // 57
      allPosts: 'All Posts',                                                                                       // 57
      myPosts: 'My Posts',                                                                                         // 57
      addPost: 'Add Post',                                                                                         // 57
      editPost: 'Edit Post',                                                                                       // 57
      title: 'Title',                                                                                              // 57
      author: 'Author',                                                                                            // 57
      updatedAt: 'Updated At',                                                                                     // 57
      publishedAt: 'Published At',                                                                                 // 57
      visibleTo: 'Visible To',                                                                                     // 57
      featuredImage: 'Featured Image',                                                                             // 57
      selectFile: 'Select File',                                                                                   // 57
      imageAsBackground: 'Use as background for title',                                                            // 57
      enterTag: 'Type in a tag & hit enter',                                                                       // 57
      postCreateFirst: 'Create the first blog',                                                                    // 57
      postVisibilityAdmins: 'Me & Admins only',                                                                    // 57
      postVisibilityLink: 'Anyone with link',                                                                      // 57
      postVisibilityAnyone: 'The world',                                                                           // 57
      saved: 'Saved',                                                                                              // 57
      editFeaturedImageSaved: 'Featured image saved',                                                              // 57
      editErrorSlugExists: 'Blog with this slug already exists',                                                   // 57
      editErrorBodyRequired: 'Blog body is required'                                                               // 57
    }                                                                                                              //
  });                                                                                                              //
}                                                                                                                  //
                                                                                                                   //
Blog.config({                                                                                                      // 1
  basePath: '/blog',                                                                                               // 105
  adminBasePath: '/admin/blog'                                                                                     // 105
});                                                                                                                //
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/collections/author.coffee.js                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                     //
                                                                                                                   //
Blog.Author = (function(superClass) {                                                                              // 1
  extend(Author, superClass);                                                                                      // 3
                                                                                                                   //
  function Author() {                                                                                              //
    return Author.__super__.constructor.apply(this, arguments);                                                    //
  }                                                                                                                //
                                                                                                                   //
  Author._collection = Meteor.users;                                                                               // 3
                                                                                                                   //
  Author.prototype.posts = function() {                                                                            // 3
    return Blog.Post.where({                                                                                       //
      userId: this.id                                                                                              // 6
    });                                                                                                            //
  };                                                                                                               //
                                                                                                                   //
  Author.current = function() {                                                                                    // 3
    if (Meteor.userId()) {                                                                                         // 9
      return Blog.Author.init(Meteor.user());                                                                      //
    }                                                                                                              //
  };                                                                                                               //
                                                                                                                   //
  return Author;                                                                                                   //
                                                                                                                   //
})(Minimongoid);                                                                                                   //
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/collections/post.coffee.js                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                     //
                                                                                                                   //
Blog.Post = (function(superClass) {                                                                                // 1
  extend(Post, superClass);                                                                                        // 3
                                                                                                                   //
  function Post() {                                                                                                //
    return Post.__super__.constructor.apply(this, arguments);                                                      //
  }                                                                                                                //
                                                                                                                   //
  Post._collection = new Meteor.Collection('blog_posts');                                                          // 3
                                                                                                                   //
  Post.after_save = function(post) {                                                                               // 3
    post.tags = Blog.Post.splitTags(post.tags);                                                                    // 6
    if (post.body) {                                                                                               // 7
      post.excerpt = Blog.Post.excerpt(post.body);                                                                 // 7
    }                                                                                                              //
    return this._collection.update({                                                                               //
      _id: post.id                                                                                                 // 9
    }, {                                                                                                           //
      $set: {                                                                                                      // 10
        tags: post.tags,                                                                                           // 11
        excerpt: post.excerpt                                                                                      // 11
      }                                                                                                            //
    });                                                                                                            //
  };                                                                                                               //
                                                                                                                   //
  Post.replace_foreign_charts = function(str) {                                                                    // 3
    var charts, foreign, local, regex;                                                                             // 15
    charts = {                                                                                                     // 15
      'ä|æ|ǽ': 'ae',                                                                                               // 16
      'ö|œ': 'oe',                                                                                                 // 16
      'ü': 'ue',                                                                                                   // 16
      'Ä': 'Ae',                                                                                                   // 16
      'Ü': 'Ue',                                                                                                   // 16
      'Ö': 'Oe',                                                                                                   // 16
      'À|Á|Â|Ã|Ä|Å|Ǻ|Ā|Ă|Ą|Ǎ': 'A',                                                                                // 16
      'à|á|â|ã|å|ǻ|ā|ă|ą|ǎ|ª': 'a',                                                                                // 16
      'Ç|Ć|Ĉ|Ċ|Č': 'C',                                                                                            // 16
      'ç|ć|ĉ|ċ|č': 'c',                                                                                            // 16
      'Ð|Ď|Đ': 'D',                                                                                                // 16
      'ð|ď|đ': 'd',                                                                                                // 16
      'È|É|Ê|Ë|Ē|Ĕ|Ė|Ę|Ě': 'E',                                                                                    // 16
      'è|é|ê|ë|ē|ĕ|ė|ę|ě': 'e',                                                                                    // 16
      'Ĝ|Ğ|Ġ|Ģ': 'G',                                                                                              // 16
      'ĝ|ğ|ġ|ģ': 'g',                                                                                              // 16
      'Ĥ|Ħ': 'H',                                                                                                  // 16
      'ĥ|ħ': 'h',                                                                                                  // 16
      'Ì|Í|Î|Ï|Ĩ|Ī|Ĭ|Ǐ|Į|İ': 'I',                                                                                  // 16
      'ì|í|î|ï|ĩ|ī|ĭ|ǐ|į|ı': 'i',                                                                                  // 16
      'Ĵ': 'J',                                                                                                    // 16
      'ĵ': 'j',                                                                                                    // 16
      'Ķ': 'K',                                                                                                    // 16
      'ķ': 'k',                                                                                                    // 16
      'Ĺ|Ļ|Ľ|Ŀ|Ł': 'L',                                                                                            // 16
      'ĺ|ļ|ľ|ŀ|ł': 'l',                                                                                            // 16
      'Ñ|Ń|Ņ|Ň': 'N',                                                                                              // 16
      'ñ|ń|ņ|ň|ŉ': 'n',                                                                                            // 16
      'Ò|Ó|Ô|Õ|Ō|Ŏ|Ǒ|Ő|Ơ|Ø|Ǿ': 'O',                                                                                // 16
      'ò|ó|ô|õ|ō|ŏ|ǒ|ő|ơ|ø|ǿ|º': 'o',                                                                              // 16
      'Ŕ|Ŗ|Ř': 'R',                                                                                                // 16
      'ŕ|ŗ|ř': 'r',                                                                                                // 16
      'Ś|Ŝ|Ş|Š': 'S',                                                                                              // 16
      'ś|ŝ|ş|š|ſ': 's',                                                                                            // 16
      'Ţ|Ť|Ŧ': 'T',                                                                                                // 16
      'ţ|ť|ŧ': 't',                                                                                                // 16
      'Ù|Ú|Û|Ũ|Ū|Ŭ|Ů|Ű|Ų|Ư|Ǔ|Ǖ|Ǘ|Ǚ|Ǜ': 'U',                                                                        // 16
      'ù|ú|û|ũ|ū|ŭ|ů|ű|ų|ư|ǔ|ǖ|ǘ|ǚ|ǜ': 'u',                                                                        // 16
      'Ý|Ÿ|Ŷ': 'Y',                                                                                                // 16
      'ý|ÿ|ŷ': 'y',                                                                                                // 16
      'Ŵ': 'W',                                                                                                    // 16
      'ŵ': 'w',                                                                                                    // 16
      'Ź|Ż|Ž': 'Z',                                                                                                // 16
      'ź|ż|ž': 'z',                                                                                                // 16
      'Æ|Ǽ': 'AE',                                                                                                 // 16
      'ß': 'ss',                                                                                                   // 16
      'Ĳ': 'IJ',                                                                                                   // 16
      'ĳ': 'ij',                                                                                                   // 16
      'Œ': 'OE',                                                                                                   // 16
      'ƒ': 'f'                                                                                                     // 16
    };                                                                                                             //
    for (foreign in charts) {                                                                                      // 66
      local = charts[foreign];                                                                                     //
      regex = new RegExp(foreign, 'g');                                                                            // 67
      str = str.replace(regex, local);                                                                             // 67
    }                                                                                                              // 66
    return str;                                                                                                    //
  };                                                                                                               //
                                                                                                                   //
  Post.slugify = function(str) {                                                                                   // 3
    var from, i, j, l, ref, to;                                                                                    // 74
    str = this.replace_foreign_charts(str);                                                                        // 74
    str = str.replace(/^\s+|\s+$/g, '');                                                                           // 74
    str = str.toLowerCase();                                                                                       // 74
    from = "·/_,:;";                                                                                               // 74
    to = "------";                                                                                                 // 74
    l = from.length;                                                                                               // 74
    for (i = j = 0, ref = l; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {                           // 80
      str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));                                            // 81
    }                                                                                                              // 80
    return str.replace(/[^a-z0-9 -]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-');                               //
  };                                                                                                               //
                                                                                                                   //
  Post.splitTags = function(str) {                                                                                 // 3
    if (str && typeof str === 'string') {                                                                          // 85
      return str.split(/,\s*/);                                                                                    // 86
    }                                                                                                              //
    return str;                                                                                                    //
  };                                                                                                               //
                                                                                                                   //
  Post.prototype.validate = function() {                                                                           // 3
    if (!this.title) {                                                                                             // 90
      this.error('title', "Blog title is required");                                                               // 91
    }                                                                                                              //
    if (!this.slug) {                                                                                              // 93
      return this.error('slug', "Blog slug is required");                                                          //
    }                                                                                                              //
  };                                                                                                               //
                                                                                                                   //
  Post.prototype.html = function() {                                                                               // 3
    return this.body;                                                                                              //
  };                                                                                                               //
                                                                                                                   //
  Post.prototype.thumbnail = function() {                                                                          // 3
    var match, ref, ref1, ref2, regex;                                                                             // 100
    if (this.featuredImage != null) {                                                                              // 100
      if ((ref = Meteor.settings) != null ? (ref1 = ref["public"]) != null ? (ref2 = ref1.blog) != null ? ref2.useS3 : void 0 : void 0 : void 0) {
        return this.featuredImage;                                                                                 //
      } else {                                                                                                     //
        return Meteor.absoluteUrl() + this.featuredImage.slice(1);                                                 //
      }                                                                                                            //
    } else {                                                                                                       //
      regex = new RegExp(/img src=[\'"]([^\'"]+)/ig);                                                              // 106
      while (match = regex.exec(this.body)) {                                                                      // 107
        return match[1];                                                                                           // 108
      }                                                                                                            //
    }                                                                                                              //
  };                                                                                                               //
                                                                                                                   //
  Post.excerpt = function(html) {                                                                                  // 3
    var i, matches, ret;                                                                                           // 111
    if (Blog.settings.excerptFunction != null) {                                                                   // 111
      return Blog.settings.excerptFunction(html);                                                                  //
    } else {                                                                                                       //
      matches = html != null ? html.split(/<\/div>|<\/p>|<\/blockquote>|<br><br>|\\n\\n|\\r\\n\\r\\n/m) : void 0;  // 115
      i = 0;                                                                                                       // 115
      ret = '';                                                                                                    // 115
      while (!ret && (matches != null ? matches[i] : void 0)) {                                                    // 119
        ret += matches[i++].replace(/(<([^>]+)>)/ig, ' ').replace(/(\s\.)/, '.').replace('&nbsp;', ' ').trim();    // 121
      }                                                                                                            //
      return ret;                                                                                                  //
    }                                                                                                              //
  };                                                                                                               //
                                                                                                                   //
  Post.prototype.author = function() {                                                                             // 3
    return Blog.Author.first(this.userId);                                                                         //
  };                                                                                                               //
                                                                                                                   //
  Post.prototype.authorName = function() {                                                                         // 3
    var author;                                                                                                    // 128
    author = this.author();                                                                                        // 128
    if (author) {                                                                                                  // 130
      if (author.profile && author.profile.name) {                                                                 // 131
        return author.profile.name;                                                                                // 132
      } else if (author.profile && author.profile.firstName && author.profile.lastName) {                          //
        return author.profile.firstName + " " + author.profile.lastName;                                           // 135
      } else if (author.profile && author.profile.twitter) {                                                       //
        return "<a href=\"http://twitter.com/" + author.profile.twitter + "\">" + author.profile.twitter + "</a>";
      } else if (author.username) {                                                                                //
        return author.username;                                                                                    // 141
      } else if (author.emails && author.emails[0]) {                                                              //
        return author.emails[0].address;                                                                           // 144
      }                                                                                                            //
    }                                                                                                              //
    return 'Mystery blogger';                                                                                      //
  };                                                                                                               //
                                                                                                                   //
  return Post;                                                                                                     //
                                                                                                                   //
})(Minimongoid);                                                                                                   //
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 153
  Meteor.methods({                                                                                                 // 154
    doesBlogExist: function(slug) {                                                                                // 155
      check(slug, String);                                                                                         // 156
      return !!Blog.Post.first({                                                                                   //
        slug: slug                                                                                                 // 158
      });                                                                                                          //
    },                                                                                                             //
    isBlogAuthorized: function() {                                                                                 // 155
      var post;                                                                                                    // 161
      check(arguments[0], Match.OneOf(Object, Number, String, null, void 0));                                      // 161
      if (!Meteor.user()) {                                                                                        // 163
        return false;                                                                                              // 164
      }                                                                                                            //
      if (!Blog.settings.adminRole && !Blog.settings.authorRole) {                                                 // 167
        return true;                                                                                               // 168
      }                                                                                                            //
      if (Blog.settings.adminRole) {                                                                               // 171
        if (Blog.settings.adminGroup) {                                                                            // 173
          if (Roles.userIsInRole(this.userId, Blog.settings.adminRole, Blog.settings.adminGroup)) {                // 175
            return true;                                                                                           // 177
          }                                                                                                        //
        } else if (Roles.userIsInRole(this.userId, Blog.settings.adminRole)) {                                     //
          return true;                                                                                             // 182
        }                                                                                                          //
      }                                                                                                            //
      if (Blog.settings.authorRole) {                                                                              // 186
        if (_.isObject(arguments[0])) {                                                                            // 189
          post = arguments[0];                                                                                     // 190
        } else if (_.isNumber(arguments[0]) || _.isString(arguments[0])) {                                         //
          post = Blog.Post.first(arguments[0]);                                                                    // 192
        } else {                                                                                                   //
          post = null;                                                                                             // 194
        }                                                                                                          //
        if (Blog.settings.authorGroup) {                                                                           // 197
          if (Roles.userIsInRole(this.userId, Blog.settings.authorRole, Blog.settings.authorGroup)) {              // 199
            if (post) {                                                                                            // 200
              if (Meteor.userId() === post.userId) {                                                               // 202
                return true;                                                                                       // 203
              }                                                                                                    //
            } else {                                                                                               //
              return true;                                                                                         // 205
            }                                                                                                      //
          }                                                                                                        //
        } else if (Roles.userIsInRole(this.userId, Blog.settings.authorRole)) {                                    //
          if (post) {                                                                                              // 209
            if (Meteor.userId() === post.userId) {                                                                 // 211
              return true;                                                                                         // 212
            }                                                                                                      //
          } else {                                                                                                 //
            return true;                                                                                           // 214
          }                                                                                                        //
        }                                                                                                          //
      }                                                                                                            //
      return false;                                                                                                //
    }                                                                                                              //
  });                                                                                                              //
}                                                                                                                  //
                                                                                                                   //
Blog.Post._collection.allow({                                                                                      // 1
  insert: function(userId, item) {                                                                                 // 225
    return Meteor.call('isBlogAuthorized', item);                                                                  //
  },                                                                                                               //
  update: function(userId, item, fields) {                                                                         // 225
    return Meteor.call('isBlogAuthorized', item);                                                                  //
  },                                                                                                               //
  remove: function(userId, item) {                                                                                 // 225
    return Meteor.call('isBlogAuthorized', item);                                                                  //
  }                                                                                                                //
});                                                                                                                //
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/collections/comment.coffee.js                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                     //
                                                                                                                   //
Blog.Comment = (function(superClass) {                                                                             // 1
  extend(Comment, superClass);                                                                                     // 3
                                                                                                                   //
  function Comment() {                                                                                             //
    return Comment.__super__.constructor.apply(this, arguments);                                                   //
  }                                                                                                                //
                                                                                                                   //
  Comment._collection = new Meteor.Collection('blog_comments');                                                    // 3
                                                                                                                   //
  Comment.prototype.post = function() {                                                                            // 3
    return Blog.Post.first(this.postId);                                                                           //
  };                                                                                                               //
                                                                                                                   //
  return Comment;                                                                                                  //
                                                                                                                   //
})(Minimongoid);                                                                                                   //
                                                                                                                   //
Blog.Comment._collection.allow({                                                                                   // 1
  insert: function(userId, doc) {                                                                                  // 9
    return !!userId;                                                                                               //
  },                                                                                                               //
  update: function(userId, doc, fields, modifier) {                                                                // 9
    return doc.comment.authorId === userId;                                                                        //
  },                                                                                                               //
  remove: function(userId, doc) {                                                                                  // 9
    return doc.comment.authorId === userId;                                                                        //
  }                                                                                                                //
});                                                                                                                //
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/collections/tag.coffee.js                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                     //
                                                                                                                   //
Blog.Tag = (function(superClass) {                                                                                 // 1
  extend(Tag, superClass);                                                                                         // 3
                                                                                                                   //
  function Tag() {                                                                                                 //
    return Tag.__super__.constructor.apply(this, arguments);                                                       //
  }                                                                                                                //
                                                                                                                   //
  Tag._collection = new Meteor.Collection('blog_tags');                                                            // 3
                                                                                                                   //
  return Tag;                                                                                                      //
                                                                                                                   //
})(Minimongoid);                                                                                                   //
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/collections/files.coffee.js                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var filesStore, ref, ref1, ref2, ref3, ref4, ref5, s3Config, s3ImportStore, useS3;                                 // 4
                                                                                                                   //
filesStore = new FS.Store.GridFS('blog_images');                                                                   // 4
                                                                                                                   //
Blog.FilesLocal = new FS.Collection('blog_images', {                                                               // 4
  stores: [filesStore],                                                                                            // 7
  filter: {                                                                                                        // 7
    allow: {                                                                                                       // 10
      contentTypes: ['image/*']                                                                                    // 11
    }                                                                                                              //
  },                                                                                                               //
  onInvalid: function(message) {                                                                                   // 7
    return console.log(message);                                                                                   //
  }                                                                                                                //
});                                                                                                                //
                                                                                                                   //
if (Meteor.isClient) {                                                                                             // 17
  Meteor.subscribe("blog.images");                                                                                 // 18
} else {                                                                                                           //
  Meteor.publish('blog.images', function() {                                                                       // 20
    return Blog.FilesLocal.find();                                                                                 //
  });                                                                                                              //
  Blog.FilesLocal.allow({                                                                                          // 20
    insert: function(userId, file) {                                                                               // 22
      return !!userId;                                                                                             //
    },                                                                                                             //
    remove: function(userId, file) {                                                                               // 22
      return file.metadata && file.metadata.userId && file.metadata.userId === userId;                             // 26
    },                                                                                                             //
    update: function() {                                                                                           // 22
      return true;                                                                                                 //
    },                                                                                                             //
    download: function(userId, file) {                                                                             // 22
      return true;                                                                                                 //
    }                                                                                                              //
  });                                                                                                              //
}                                                                                                                  //
                                                                                                                   //
useS3 = (ref = Meteor.settings) != null ? (ref1 = ref["public"]) != null ? (ref2 = ref1.blog) != null ? ref2.useS3 : void 0 : void 0 : void 0;
                                                                                                                   //
if (Meteor.isClient && useS3) {                                                                                    // 40
  s3ImportStore = new FS.Store.S3("blog_s3Imports");                                                               // 41
  Blog.S3Files = new FS.Collection("blog_s3Imports", {                                                             // 41
    stores: [s3ImportStore],                                                                                       // 44
    filter: {                                                                                                      // 44
      allow: {                                                                                                     // 47
        contentTypes: ['image/*']                                                                                  // 48
      }                                                                                                            //
    },                                                                                                             //
    onInvalid: function(message) {                                                                                 // 44
      return console.log(message);                                                                                 //
    }                                                                                                              //
  });                                                                                                              //
  Meteor.subscribe("blog.s3Imports");                                                                              // 41
}                                                                                                                  //
                                                                                                                   //
if (Meteor.isServer && useS3) {                                                                                    // 56
  s3Config = (ref3 = Meteor.settings) != null ? (ref4 = ref3["private"]) != null ? (ref5 = ref4.blog) != null ? ref5.s3Config : void 0 : void 0 : void 0;
  s3ImportStore = new FS.Store.S3("blog_s3Imports", {                                                              // 57
    accessKeyId: s3Config.accessKeyId,                                                                             // 59
    secretAccessKey: s3Config.secretAccessKey,                                                                     // 59
    bucket: s3Config.bucket,                                                                                       // 59
    ACL: s3Config.s3ACL,                                                                                           // 59
    maxTries: s3Config.s3MaxTries,                                                                                 // 59
    region: s3Config.region                                                                                        // 59
  });                                                                                                              //
  Blog.S3Files = new FS.Collection("blog_s3Imports", {                                                             // 57
    stores: [s3ImportStore],                                                                                       // 67
    filter: {                                                                                                      // 67
      allow: {                                                                                                     // 70
        contentTypes: ['image/*']                                                                                  // 71
      }                                                                                                            //
    },                                                                                                             //
    onInvalid: function(message) {                                                                                 // 67
      return console.log(message);                                                                                 //
    }                                                                                                              //
  });                                                                                                              //
  Meteor.publish('blog.s3Imports', function() {                                                                    // 57
    return Blog.S3Files.find();                                                                                    //
  });                                                                                                              //
  Blog.S3Files.allow({                                                                                             // 57
    insert: function(userId, file) {                                                                               // 79
      return userId;                                                                                               //
    },                                                                                                             //
    remove: function(userId, file) {                                                                               // 79
      return file.metadata && file.metadata.userId && file.metadata.userId === userId;                             // 83
    },                                                                                                             //
    update: function() {                                                                                           // 79
      return true;                                                                                                 //
    },                                                                                                             //
    download: function(userId, file) {                                                                             // 79
      return true;                                                                                                 //
    }                                                                                                              //
  });                                                                                                              //
}                                                                                                                  //
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/router.coffee.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Blog.Router = {                                                                                                    // 3
  routes: [],                                                                                                      // 4
  getNotFoundTemplate: function() {                                                                                // 4
    if (Package['iron:router']) {                                                                                  // 7
      return Router.lookupNotFoundTemplate();                                                                      //
    }                                                                                                              //
  },                                                                                                               //
  notFound: function() {                                                                                           // 4
    if (Package['kadira:flow-router']) {                                                                           // 11
      return FlowRouter._notfoundRoute(FlowRouter.current());                                                      //
    }                                                                                                              //
  },                                                                                                               //
  replaceState: function(path) {                                                                                   // 4
    if (Package['iron:router']) {                                                                                  // 15
      return Iron.Location.go(path, {                                                                              //
        replaceState: true,                                                                                        // 16
        skipReactive: true                                                                                         // 16
      });                                                                                                          //
    } else if (Package['kadira:flow-router']) {                                                                    //
      return FlowRouter.withReplaceState(function() {                                                              //
        return FlowRouter.go(path);                                                                                //
      });                                                                                                          //
    }                                                                                                              //
  },                                                                                                               //
  go: function(nameOrPath, params, options) {                                                                      // 4
    var path, route, router, url;                                                                                  // 21
    router = Package['iron:router'] ? Package['iron:router'].Router : Package['kadira:flow-router'] ? Package['kadira:flow-router'].FlowRouter : void 0;
    if (/^\/|http/.test(nameOrPath)) {                                                                             // 27
      path = nameOrPath;                                                                                           // 28
    } else {                                                                                                       //
      route = _.findWhere(this.routes, {                                                                           // 30
        name: nameOrPath                                                                                           // 30
      });                                                                                                          //
      if (!route) {                                                                                                // 31
        throw new Meteor.Error(500, "Route named '" + nameOrPath + "' not found");                                 // 32
      }                                                                                                            //
      if (options == null) {                                                                                       //
        options = {};                                                                                              //
      }                                                                                                            //
      url = new Iron.Url(route.path);                                                                              // 30
      path = url.resolve(params, options);                                                                         // 30
    }                                                                                                              //
    return router.go(path);                                                                                        //
  },                                                                                                               //
  getLocation: function() {                                                                                        // 4
    if (Package['iron:router']) {                                                                                  // 39
      return '/' + Router.current().params[0];                                                                     //
    } else if (Package['kadira:flow-router']) {                                                                    //
      FlowRouter.watchPathChange();                                                                                // 42
      return FlowRouter.current().path;                                                                            //
    }                                                                                                              //
  },                                                                                                               //
  getParam: function(key) {                                                                                        // 4
    var location, match, params, url;                                                                              // 46
    location = this.getLocation();                                                                                 // 46
    url = null;                                                                                                    // 46
    match = _.find(this.routes, function(route) {                                                                  // 46
      url = new Iron.Url(route.path);                                                                              // 49
      return url.test(location);                                                                                   //
    });                                                                                                            //
    if (match) {                                                                                                   // 51
      params = url.params(location);                                                                               // 52
      return params[key];                                                                                          // 53
    }                                                                                                              //
  },                                                                                                               //
  pathFor: function(name, params, options) {                                                                       // 4
    var opts, route, url;                                                                                          // 56
    route = _.findWhere(this.routes, {                                                                             // 56
      name: name                                                                                                   // 56
    });                                                                                                            //
    if (!route) {                                                                                                  // 57
      throw new Meteor.Error(500, "Route named '" + name + "' not found");                                         // 58
    }                                                                                                              //
    opts = options && (options.hash || {});                                                                        // 56
    url = new Iron.Url(route.path);                                                                                // 56
    return url.resolve(params, opts);                                                                              //
  },                                                                                                               //
  getTemplate: function() {                                                                                        // 4
    var location, match, name, url;                                                                                // 64
    location = this.getLocation();                                                                                 // 64
    url = null;                                                                                                    // 64
    match = _.find(this.routes, function(route) {                                                                  // 64
      url = new Iron.Url(route.path);                                                                              // 67
      return url.test(location);                                                                                   //
    });                                                                                                            //
    if (match) {                                                                                                   // 69
      name = match.name;                                                                                           // 70
      if (name === 'blogTagged') {                                                                                 // 73
        name = 'blogIndex';                                                                                        // 74
      }                                                                                                            //
      if (Blog.settings[name + "Template"]) {                                                                      // 77
        name = Blog.settings[name + "Template"];                                                                   // 78
      }                                                                                                            //
      return name;                                                                                                 // 79
    }                                                                                                              //
  },                                                                                                               //
  routeAll: function(routes) {                                                                                     // 4
    var catchAll, catchAllHook;                                                                                    // 82
    this.routes = routes;                                                                                          // 82
    if (Package['iron:router']) {                                                                                  // 87
      if (Meteor.isServer) {                                                                                       // 89
        routes.forEach(function(route) {                                                                           // 90
          if (route.fastRender) {                                                                                  // 91
            return FastRender.route(route.path, route.fastRender);                                                 //
          }                                                                                                        //
        });                                                                                                        //
      }                                                                                                            //
      catchAll = _.findWhere(Package['iron:router'].Router.routes, {                                               // 89
        _path: '/(.*)'                                                                                             // 94
      });                                                                                                          //
      if (catchAll) {                                                                                              // 95
        catchAllHook = catchAll.options.onBeforeAction;                                                            // 99
        return catchAll.options.onBeforeAction = function() {                                                      // 100
          var template;                                                                                            // 101
          template = Blog.Router.getTemplate();                                                                    // 101
          if (template) {                                                                                          // 102
            if (Blog.settings.blogLayoutTemplate) {                                                                // 103
              this.layout(Blog.settings.blogLayoutTemplate);                                                       // 104
            }                                                                                                      //
            return this.render(template);                                                                          //
          } else if (catchAllHook) {                                                                               //
            return catchAllHook.call(this);                                                                        //
          } else {                                                                                                 //
            return this.next();                                                                                    //
          }                                                                                                        //
        };                                                                                                         //
      }                                                                                                            //
      return Package['iron:router'].Router.route('/(.*)', {                                                        //
        onBeforeAction: function() {                                                                               // 112
          var template;                                                                                            // 113
          template = Blog.Router.getTemplate();                                                                    // 113
          if (template) {                                                                                          // 114
            if (Blog.settings.blogLayoutTemplate) {                                                                // 115
              this.layout(Blog.settings.blogLayoutTemplate);                                                       // 116
            }                                                                                                      //
            return this.render(template);                                                                          //
          } else {                                                                                                 //
            return this.next();                                                                                    //
          }                                                                                                        //
        },                                                                                                         //
        action: function() {                                                                                       // 112
          return this.next();                                                                                      //
        }                                                                                                          //
      });                                                                                                          //
    } else if (Package['kadira:flow-router']) {                                                                    //
      return Package['kadira:flow-router'].FlowRouter.route('/:any*', {                                            //
        action: function() {                                                                                       // 128
          var layout, template;                                                                                    // 129
          template = Blog.Router.getTemplate();                                                                    // 129
          if (template) {                                                                                          // 130
            if (Blog.settings.blogLayoutTemplate) {                                                                // 131
              layout = Blog.settings.blogLayoutTemplate;                                                           // 132
              return BlazeLayout.render(layout, {                                                                  //
                template: template                                                                                 // 133
              });                                                                                                  //
            } else {                                                                                               //
              return BlazeLayout.render(template);                                                                 //
            }                                                                                                      //
          } else {                                                                                                 //
            return Blog.Router.notFound();                                                                         //
          }                                                                                                        //
        }                                                                                                          //
      });                                                                                                          //
    } else {                                                                                                       //
      throw new Meteor.Error(500, 'Blog requires either iron:router or kadira:flow-router');                       // 141
    }                                                                                                              //
  }                                                                                                                //
};                                                                                                                 //
                                                                                                                   //
if (Package['kadira:flow-router']) {                                                                               // 144
  Package['kadira:flow-router'].FlowRouter.wait();                                                                 // 145
}                                                                                                                  //
                                                                                                                   //
Meteor.startup(function() {                                                                                        // 3
  var adminBasePath, basePath, routes;                                                                             // 148
  if (Meteor.isClient) {                                                                                           // 148
    Session.set('time', new Date());                                                                               // 149
    console.log('start:', Session.get('time'));                                                                    // 149
  }                                                                                                                //
  routes = [];                                                                                                     // 148
  basePath = Blog.settings.basePath === '/' ? '' : Blog.settings.basePath;                                         // 148
  adminBasePath = Blog.settings.adminBasePath === '/' ? '' : Blog.settings.adminBasePath;                          // 148
  routes.push({                                                                                                    // 148
    path: basePath || '/',                                                                                         // 172
    name: 'blogIndex',                                                                                             // 172
    fastRender: function() {                                                                                       // 172
      this.subscribe('blog.authors');                                                                              // 175
      return this.subscribe('blog.posts');                                                                         //
    }                                                                                                              //
  });                                                                                                              //
  routes.push({                                                                                                    // 148
    path: basePath + '/tag/:tag',                                                                                  // 181
    name: 'blogTagged',                                                                                            // 181
    fastRender: function(params) {                                                                                 // 181
      this.subscribe('blog.authors');                                                                              // 184
      return this.subscribe('blog.taggedPosts', params.tag);                                                       //
    }                                                                                                              //
  });                                                                                                              //
  routes.push({                                                                                                    // 148
    path: basePath + '/:slug',                                                                                     // 190
    name: 'blogShow',                                                                                              // 190
    fastRender: function(params) {                                                                                 // 190
      this.subscribe('blog.authors');                                                                              // 193
      this.subscribe('blog.singlePostBySlug', params.slug);                                                        // 193
      return this.subscribe('blog.commentsBySlug', params.slug);                                                   //
    }                                                                                                              //
  });                                                                                                              //
  routes.push({                                                                                                    // 148
    path: adminBasePath,                                                                                           // 205
    name: 'blogAdmin'                                                                                              // 205
  });                                                                                                              //
  routes.push({                                                                                                    // 148
    path: adminBasePath + '/edit/:id',                                                                             // 211
    name: 'blogAdminEdit'                                                                                          // 211
  });                                                                                                              //
  Blog.Router.routeAll(routes);                                                                                    // 148
  if (Package['kadira:flow-router']) {                                                                             // 216
    return FlowRouter.initialize();                                                                                //
  }                                                                                                                //
});                                                                                                                // 147
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/collections/config.coffee.js                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                     //
                                                                                                                   //
Blog.Config = (function(superClass) {                                                                              // 1
  extend(Config, superClass);                                                                                      // 3
                                                                                                                   //
  function Config() {                                                                                              //
    return Config.__super__.constructor.apply(this, arguments);                                                    //
  }                                                                                                                //
                                                                                                                   //
  Config._collection = new Meteor.Collection('blog_config');                                                       // 3
                                                                                                                   //
  return Config;                                                                                                   //
                                                                                                                   //
})(Minimongoid);                                                                                                   //
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/server/boot.coffee.js                                                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.startup(function() {                                                                                        // 5
  var arr, classPattern, html, i, index, obj, para, results;                                                       // 11
  Blog.Post._collection._ensureIndex({                                                                             // 11
    'slug': 1                                                                                                      // 11
  });                                                                                                              //
  Blog.Comment._collection._ensureIndex({                                                                          // 11
    'slug': 1                                                                                                      // 12
  });                                                                                                              //
  if (Blog.Post.where({                                                                                            // 15
    excerpt: {                                                                                                     // 15
      $exists: 0                                                                                                   // 15
    }                                                                                                              //
  }).length) {                                                                                                     //
    arr = Blog.Post.where({                                                                                        // 16
      excerpt: {                                                                                                   // 16
        $exists: 0                                                                                                 // 16
      }                                                                                                            //
    });                                                                                                            //
    i = 0;                                                                                                         // 16
    while (i < arr.length) {                                                                                       // 18
      obj = arr[i++];                                                                                              // 19
      obj.update({                                                                                                 // 19
        excerpt: Blog.Post.excerpt(obj.body)                                                                       // 20
      });                                                                                                          //
    }                                                                                                              //
  }                                                                                                                //
  if (!Blog.Config.first()) {                                                                                      // 23
    Blog.Config.create({                                                                                           // 24
      versions: ['0.5.0']                                                                                          // 24
    });                                                                                                            //
  } else {                                                                                                         //
    Blog.Config.first().push({                                                                                     // 26
      versions: '0.5.0'                                                                                            // 26
    });                                                                                                            //
  }                                                                                                                //
  arr = Blog.Post.all();                                                                                           // 11
  i = 0;                                                                                                           // 11
  while (i < arr.length) {                                                                                         // 31
    obj = arr[i++];                                                                                                // 32
    html = obj.body;                                                                                               // 32
    para = /<p[^>]*>/g;                                                                                            // 32
    classPattern = /class=[\"|\'].*[\"|\']/g;                                                                      // 32
    if ((html != null ? html.indexOf('commentable-section') : void 0) < 0) {                                       // 36
      index = 0;                                                                                                   // 37
      html = html.replace(para, function(ele) {                                                                    // 37
        var newEle;                                                                                                // 39
        if (classPattern.test(ele)) {                                                                              // 39
          newEle = ele.replace('class=\"', 'class=\"commentable-section');                                         // 40
        } else {                                                                                                   //
          newEle = ele.replace('>', ' class=\"commentable-section\">');                                            // 42
        }                                                                                                          //
        newEle = newEle.replace('>', " data-section-id=\"" + index + "\">");                                       // 39
        index++;                                                                                                   // 39
        return newEle;                                                                                             // 45
      });                                                                                                          //
      obj.update({                                                                                                 // 37
        body: html                                                                                                 // 47
      });                                                                                                          //
    }                                                                                                              //
  }                                                                                                                //
  if (Blog.Tag.count() === 0) {                                                                                    // 50
    Blog.Tag.create({                                                                                              // 51
      tags: ['meteor']                                                                                             // 52
    });                                                                                                            //
  }                                                                                                                //
  arr = Blog.Post.all();                                                                                           // 11
  i = 0;                                                                                                           // 11
  results = [];                                                                                                    // 57
  while (i < arr.length) {                                                                                         //
    obj = arr[i++];                                                                                                // 58
    if (obj.mode == null) {                                                                                        // 59
      if (obj.published) {                                                                                         // 60
        results.push(obj.update({                                                                                  //
          mode: 'public'                                                                                           // 61
        }));                                                                                                       //
      } else {                                                                                                     //
        if (Blog.settings.publicDrafts) {                                                                          // 63
          results.push(obj.update({                                                                                //
            mode: 'private'                                                                                        // 64
          }));                                                                                                     //
        } else {                                                                                                   //
          results.push(obj.update({                                                                                //
            mode: 'draft'                                                                                          // 66
          }));                                                                                                     //
        }                                                                                                          //
      }                                                                                                            //
    } else {                                                                                                       //
      results.push(void 0);                                                                                        //
    }                                                                                                              //
  }                                                                                                                //
  return results;                                                                                                  //
});                                                                                                                // 5
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ryw_blog/server/publications.coffee.js                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('blog.commentsBySlug', function(slug) {                                                             // 6
  check(slug, String);                                                                                             // 7
  return Blog.Comment.find({                                                                                       //
    slug: slug                                                                                                     // 9
  });                                                                                                              //
});                                                                                                                // 6
                                                                                                                   //
Meteor.publish('blog.singlePostBySlug', function(slug) {                                                           // 6
  check(slug, String);                                                                                             // 12
  return Blog.Post.find({                                                                                          //
    slug: slug                                                                                                     // 14
  });                                                                                                              //
});                                                                                                                // 11
                                                                                                                   //
Meteor.publish('blog.posts', function(limit) {                                                                     // 6
  check(limit, Match.Optional(Number));                                                                            // 17
  if (limit == null) {                                                                                             // 19
    return this.ready();                                                                                           // 19
  }                                                                                                                //
  return Blog.Post.find({                                                                                          //
    mode: 'public'                                                                                                 // 22
  }, {                                                                                                             //
    fields: {                                                                                                      // 24
      body: 0                                                                                                      // 24
    },                                                                                                             //
    sort: {                                                                                                        // 24
      publishedAt: -1                                                                                              // 25
    },                                                                                                             //
    limit: limit                                                                                                   // 24
  });                                                                                                              //
});                                                                                                                // 16
                                                                                                                   //
Meteor.publish('blog.taggedPosts', function(tag) {                                                                 // 6
  check(tag, String);                                                                                              // 29
  return Blog.Post.find({                                                                                          //
    mode: 'public',                                                                                                // 32
    tags: tag                                                                                                      // 32
  }, {                                                                                                             //
    fields: {                                                                                                      // 35
      body: 0                                                                                                      // 35
    },                                                                                                             //
    sort: {                                                                                                        // 35
      publishedAt: -1                                                                                              // 36
    }                                                                                                              //
  });                                                                                                              //
});                                                                                                                // 28
                                                                                                                   //
Meteor.publish('blog.authors', function() {                                                                        // 6
  var ids;                                                                                                         // 39
  ids = _.uniq(_.pluck(Blog.Post.all({                                                                             // 39
    fields: {                                                                                                      // 39
      userId: 1                                                                                                    // 39
    }                                                                                                              //
  }), 'userId'));                                                                                                  //
  return Blog.Author.find({                                                                                        //
    _id: {                                                                                                         // 42
      $in: ids                                                                                                     // 42
    }                                                                                                              //
  }, {                                                                                                             //
    fields: {                                                                                                      // 44
      profile: 1,                                                                                                  // 45
      username: 1,                                                                                                 // 45
      emails: 1                                                                                                    // 45
    }                                                                                                              //
  });                                                                                                              //
});                                                                                                                // 38
                                                                                                                   //
Meteor.publish('blog.singlePostById', function(id) {                                                               // 6
  check(id, Match.OneOf(String, null));                                                                            // 55
  if (!this.userId) {                                                                                              // 57
    return this.ready();                                                                                           // 58
  }                                                                                                                //
  return Blog.Post.find({                                                                                          //
    _id: id                                                                                                        // 60
  });                                                                                                              //
});                                                                                                                // 54
                                                                                                                   //
Meteor.publish('blog.postTags', function() {                                                                       // 6
  var handle, initializing, tags;                                                                                  // 63
  if (!this.userId) {                                                                                              // 63
    return this.ready();                                                                                           // 64
  }                                                                                                                //
  initializing = true;                                                                                             // 63
  tags = Blog.Tag.first().tags;                                                                                    // 63
  handle = Blog.Post.find({}, {                                                                                    // 63
    fields: {                                                                                                      // 69
      tags: 1                                                                                                      // 69
    }                                                                                                              //
  }).observeChanges({                                                                                              //
    added: (function(_this) {                                                                                      // 70
      return function(id, fields) {                                                                                //
        var doc;                                                                                                   // 71
        if (fields.tags) {                                                                                         // 71
          doc = Blog.Tag.first();                                                                                  // 72
          tags = _.uniq(doc.tags.concat(Blog.Post.splitTags(fields.tags)));                                        // 72
          doc.update({                                                                                             // 72
            tags: tags                                                                                             // 74
          });                                                                                                      //
          if (!initializing) {                                                                                     // 75
            return _this.changed('blog_tags', 42, {                                                                //
              tags: tags                                                                                           // 75
            });                                                                                                    //
          }                                                                                                        //
        }                                                                                                          //
      };                                                                                                           //
    })(this),                                                                                                      //
    changed: (function(_this) {                                                                                    // 70
      return function(id, fields) {                                                                                //
        var doc;                                                                                                   // 78
        if (fields.tags) {                                                                                         // 78
          doc = Blog.Tag.first();                                                                                  // 79
          tags = _.uniq(doc.tags.concat(Blog.Post.splitTags(fields.tags)));                                        // 79
          doc.update({                                                                                             // 79
            tags: tags                                                                                             // 81
          });                                                                                                      //
          if (!initializing) {                                                                                     // 82
            return _this.changed('blog_tags', 42, {                                                                //
              tags: tags                                                                                           // 82
            });                                                                                                    //
          }                                                                                                        //
        }                                                                                                          //
      };                                                                                                           //
    })(this)                                                                                                       //
  });                                                                                                              //
  initializing = false;                                                                                            // 63
  this.added('blog_tags', 42, {                                                                                    // 63
    tags: tags                                                                                                     // 85
  });                                                                                                              //
  this.ready();                                                                                                    // 63
  return this.onStop(function() {                                                                                  //
    return handle.stop();                                                                                          //
  });                                                                                                              //
});                                                                                                                // 62
                                                                                                                   //
Meteor.publish('blog.postForAdmin', function() {                                                                   // 6
  var sel;                                                                                                         // 90
  if (!this.userId) {                                                                                              // 90
    return this.ready();                                                                                           // 91
  }                                                                                                                //
  sel = {};                                                                                                        // 90
  if (Blog.settings.authorRole && Roles.userIsInRole(this.userId, Blog.settings.authorRole)) {                     // 96
    sel = {                                                                                                        // 97
      userId: this.userId                                                                                          // 97
    };                                                                                                             //
  }                                                                                                                //
  return Blog.Post.find(sel, {                                                                                     //
    fields: {                                                                                                      // 100
      body: 0                                                                                                      // 100
    },                                                                                                             //
    sort: {                                                                                                        // 100
      publishedAt: -1                                                                                              // 101
    }                                                                                                              //
  });                                                                                                              //
});                                                                                                                // 89
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ryw:blog'] = {};

})();

//# sourceMappingURL=ryw_blog.js.map
