(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var _s = Package['mrt:underscore-string-latest']._s;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/kaptron_minimongoid/lib/relation.coffee.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty,                                                                                        //
  slice = [].slice;                                                                                                   //
                                                                                                                      //
this.Relation = (function(superClass) {                                                                               // 1
  extend(Relation, superClass);                                                                                       // 2
                                                                                                                      //
  function Relation() {                                                                                               // 2
    var args, klass;                                                                                                  // 3
    klass = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];                               // 3
    this.klass = klass;                                                                                               // 3
    this.elems = args;                                                                                                // 3
    this.selector = {};                                                                                               // 3
    this.push.apply(this, args);                                                                                      // 3
  }                                                                                                                   //
                                                                                                                      //
  Relation["new"] = function() {                                                                                      // 2
    var args, klass;                                                                                                  // 9
    klass = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];                               // 9
    return (function(func, args, ctor) {                                                                              //
      ctor.prototype = func.prototype;                                                                                //
      var child = new ctor, result = func.apply(child, args);                                                         //
      return Object(result) === result ? result : child;                                                              //
    })(this, [klass].concat(slice.call(args)), function(){});                                                         //
  };                                                                                                                  //
                                                                                                                      //
  Relation.prototype.toArray = function() {                                                                           // 2
    return this.elems;                                                                                                //
  };                                                                                                                  //
                                                                                                                      //
  Relation.prototype.relationClass = function() {                                                                     // 2
    return this.klass;                                                                                                //
  };                                                                                                                  //
                                                                                                                      //
  Relation.prototype.setQuery = function(selector) {                                                                  // 2
    if (selector == null) {                                                                                           //
      selector = {};                                                                                                  //
    }                                                                                                                 //
    return this.selector = selector;                                                                                  //
  };                                                                                                                  //
                                                                                                                      //
  Relation.prototype.create = function(attr) {                                                                        // 2
    this.selector || (this.selector = {});                                                                            // 21
    return this.klass.create(_.extend(this.selector, attr));                                                          //
  };                                                                                                                  //
                                                                                                                      //
  return Relation;                                                                                                    //
                                                                                                                      //
})(Array);                                                                                                            //
                                                                                                                      //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/kaptron_minimongoid/lib/has_many_relation.coffee.js                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty,                                                                                        //
  slice = [].slice;                                                                                                   //
                                                                                                                      //
this.HasManyRelation = (function(superClass) {                                                                        // 1
  extend(HasManyRelation, superClass);                                                                                // 2
                                                                                                                      //
  function HasManyRelation() {                                                                                        // 2
    var args, foreign_key, id, klass;                                                                                 // 3
    klass = arguments[0], foreign_key = arguments[1], id = arguments[2], args = 4 <= arguments.length ? slice.call(arguments, 3) : [];
    this.link = {};                                                                                                   // 3
    this.link[foreign_key] = id;                                                                                      // 3
    this.foreign_key = foreign_key;                                                                                   // 3
    HasManyRelation.__super__.constructor.apply(this, [klass].concat(slice.call(args)));                              // 3
  }                                                                                                                   //
                                                                                                                      //
  HasManyRelation["new"] = function() {                                                                               // 2
    var args, foreign_key, id, klass;                                                                                 // 9
    klass = arguments[0], foreign_key = arguments[1], id = arguments[2], args = 4 <= arguments.length ? slice.call(arguments, 3) : [];
    return (function(func, args, ctor) {                                                                              //
      ctor.prototype = func.prototype;                                                                                //
      var child = new ctor, result = func.apply(child, args);                                                         //
      return Object(result) === result ? result : child;                                                              //
    })(this, [klass, foreign_key, id].concat(slice.call(args)), function(){});                                        //
  };                                                                                                                  //
                                                                                                                      //
  HasManyRelation.fromRelation = function(relation, foreign_key, id) {                                                // 2
    return (function(func, args, ctor) {                                                                              //
      ctor.prototype = func.prototype;                                                                                //
      var child = new ctor, result = func.apply(child, args);                                                         //
      return Object(result) === result ? result : child;                                                              //
    })(this, [relation.relationClass(), foreign_key, id].concat(slice.call(relation.toArray())), function(){});       //
  };                                                                                                                  //
                                                                                                                      //
  HasManyRelation.prototype.create = function(attr) {                                                                 // 2
    return HasManyRelation.__super__.create.call(this, _.extend(attr, this.link));                                    //
  };                                                                                                                  //
                                                                                                                      //
  return HasManyRelation;                                                                                             //
                                                                                                                      //
})(this.Relation);                                                                                                    //
                                                                                                                      //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/kaptron_minimongoid/lib/has_and_belongs_to_many_relation.coffee.js                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty,                                                                                        //
  slice = [].slice;                                                                                                   //
                                                                                                                      //
this.HasAndBelongsToManyRelation = (function(superClass) {                                                            // 1
  extend(HasAndBelongsToManyRelation, superClass);                                                                    // 2
                                                                                                                      //
  function HasAndBelongsToManyRelation() {                                                                            // 2
    var args, id, identifier, instance, inverse_identifier, klass;                                                    // 3
    instance = arguments[0], klass = arguments[1], identifier = arguments[2], inverse_identifier = arguments[3], id = arguments[4], args = 6 <= arguments.length ? slice.call(arguments, 5) : [];
    this.instance = instance;                                                                                         // 3
    this.inverse_identifier = inverse_identifier;                                                                     // 3
    this.link = {};                                                                                                   // 3
    this.link[identifier] = [id];                                                                                     // 3
    HasAndBelongsToManyRelation.__super__.constructor.apply(this, [klass].concat(slice.call(args)));                  // 3
  }                                                                                                                   //
                                                                                                                      //
  HasAndBelongsToManyRelation["new"] = function() {                                                                   // 2
    var args, id, identifier, instance, inverse_identifier, klass;                                                    // 10
    instance = arguments[0], klass = arguments[1], identifier = arguments[2], inverse_identifier = arguments[3], id = arguments[4], args = 6 <= arguments.length ? slice.call(arguments, 5) : [];
    return (function(func, args, ctor) {                                                                              //
      ctor.prototype = func.prototype;                                                                                //
      var child = new ctor, result = func.apply(child, args);                                                         //
      return Object(result) === result ? result : child;                                                              //
    })(this, [instance, klass, identifier, inverse_identifier, id].concat(slice.call(args)), function(){});           //
  };                                                                                                                  //
                                                                                                                      //
  HasAndBelongsToManyRelation.fromRelation = function(relation, instance, identifier, inverse_identifier, id) {       // 2
    return (function(func, args, ctor) {                                                                              //
      ctor.prototype = func.prototype;                                                                                //
      var child = new ctor, result = func.apply(child, args);                                                         //
      return Object(result) === result ? result : child;                                                              //
    })(this, [instance, relation.relationClass(), identifier, inverse_identifier, id].concat(slice.call(relation.toArray())), function(){});
  };                                                                                                                  //
                                                                                                                      //
  HasAndBelongsToManyRelation.prototype.create = function(attr) {                                                     // 2
    var obj;                                                                                                          // 16
    obj = HasAndBelongsToManyRelation.__super__.create.call(this, _.extend(attr, this.link));                         // 16
    attr = {};                                                                                                        // 16
    if (this.instance[this.inverse_identifier].length === 0) {                                                        // 18
      attr[this.inverse_identifier] = [obj.id];                                                                       // 19
      this.instance.update(attr);                                                                                     // 19
    } else {                                                                                                          //
      this.instance.push(attr);                                                                                       // 22
    }                                                                                                                 //
    return obj;                                                                                                       //
  };                                                                                                                  //
                                                                                                                      //
  return HasAndBelongsToManyRelation;                                                                                 //
                                                                                                                      //
})(this.Relation);                                                                                                    //
                                                                                                                      //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/kaptron_minimongoid/lib/minimongoid.coffee.js                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var global,                                                                                                           // 1
  hasProp = {}.hasOwnProperty,                                                                                        //
  slice = [].slice;                                                                                                   //
                                                                                                                      //
global = this;                                                                                                        // 1
                                                                                                                      //
this.Minimongoid = (function() {                                                                                      // 1
  Minimongoid.prototype.id = void 0;                                                                                  // 5
                                                                                                                      //
  Minimongoid.prototype.errors = false;                                                                               // 5
                                                                                                                      //
  function Minimongoid(attr, parent, is_new) {                                                                        // 10
    if (attr == null) {                                                                                               //
      attr = {};                                                                                                      //
    }                                                                                                                 //
    if (parent == null) {                                                                                             //
      parent = null;                                                                                                  //
    }                                                                                                                 //
    if (is_new == null) {                                                                                             //
      is_new = true;                                                                                                  //
    }                                                                                                                 //
    this.__is_new = !!is_new;                                                                                         // 11
    if (attr._id) {                                                                                                   // 12
      if (this.constructor._object_id) {                                                                              // 13
        this.id = attr._id._str;                                                                                      // 14
      } else {                                                                                                        //
        this.id = attr._id;                                                                                           // 16
      }                                                                                                               //
      this._id = this.id;                                                                                             // 13
    }                                                                                                                 //
    this.initAttrsAndRelations(attr, parent);                                                                         // 11
  }                                                                                                                   //
                                                                                                                      //
  Minimongoid.prototype.initAttrsAndRelations = function(attr, parent) {                                              // 5
    var belongs_to, class_name, embeds_many, foreign_key, habtm, has_many, has_one, identifier, j, l, len, len1, len2, len3, len4, len5, m, n, name, name1, o, p, ref, ref1, ref2, ref3, ref4, ref5, ref6, relation, results, selector, self, val, value;
    if (attr == null) {                                                                                               //
      attr = {};                                                                                                      //
    }                                                                                                                 //
    if (parent == null) {                                                                                             //
      parent = null;                                                                                                  //
    }                                                                                                                 //
    ref = this.constructor.has_and_belongs_to_many;                                                                   // 24
    for (j = 0, len = ref.length; j < len; j++) {                                                                     // 24
      habtm = ref[j];                                                                                                 //
      identifier = (_.singularize(habtm.name)) + "_ids";                                                              // 26
      this[identifier] || (this[identifier] = []);                                                                    // 26
    }                                                                                                                 // 24
    ref1 = this.constructor.embeds_many;                                                                              // 29
    for (l = 0, len1 = ref1.length; l < len1; l++) {                                                                  // 29
      embeds_many = ref1[l];                                                                                          //
      this[name1 = embeds_many.name] || (this[name1] = []);                                                           // 30
    }                                                                                                                 // 29
    if (this.constructor.embedded_in && parent) {                                                                     // 32
      this[this.constructor.embedded_in] = parent;                                                                    // 33
    }                                                                                                                 //
    for (name in attr) {                                                                                              // 37
      value = attr[name];                                                                                             //
      if (name.match(/^_id/)) {                                                                                       // 38
        continue;                                                                                                     // 38
      }                                                                                                               //
      if (name.match(/_id$/) && (value instanceof Meteor.Collection.ObjectID)) {                                      // 39
        this[name] = value._str;                                                                                      // 40
      } else if ((embeds_many = _.findWhere(this.constructor.embeds_many, {                                           //
        name: name                                                                                                    // 41
      }))) {                                                                                                          //
        class_name = embeds_many.class_name || _.classify(_.singularize(name));                                       // 44
        this[name] = global[class_name].modelize(value, this);                                                        // 44
      } else {                                                                                                        //
        this[name] = value;                                                                                           // 47
      }                                                                                                               //
    }                                                                                                                 // 37
    ref2 = this.constructor.defaults;                                                                                 // 50
    for (attr in ref2) {                                                                                              // 50
      if (!hasProp.call(ref2, attr)) continue;                                                                        //
      val = ref2[attr];                                                                                               //
      if (typeof this[attr] === 'undefined') {                                                                        // 51
        this[attr] = val;                                                                                             // 51
      }                                                                                                               //
    }                                                                                                                 // 50
    self = this;                                                                                                      // 24
    ref3 = this.constructor.belongs_to;                                                                               // 57
    for (m = 0, len2 = ref3.length; m < len2; m++) {                                                                  // 57
      belongs_to = ref3[m];                                                                                           //
      relation = belongs_to.name;                                                                                     // 58
      identifier = belongs_to.identifier || (relation + "_id");                                                       // 58
      class_name = belongs_to.class_name || _.titleize(relation);                                                     // 58
      this[relation] = (function(relation, identifier, class_name) {                                                  // 58
        return function(options) {                                                                                    //
          if (options == null) {                                                                                      //
            options = {};                                                                                             //
          }                                                                                                           //
          if (global[class_name] && self[identifier]) {                                                               // 66
            return global[class_name].find(self[identifier], options);                                                // 67
          } else {                                                                                                    //
            return false;                                                                                             // 69
          }                                                                                                           //
        };                                                                                                            //
      })(relation, identifier, class_name);                                                                           //
    }                                                                                                                 // 57
    ref4 = this.constructor.has_many;                                                                                 // 73
    for (n = 0, len3 = ref4.length; n < len3; n++) {                                                                  // 73
      has_many = ref4[n];                                                                                             //
      relation = has_many.name;                                                                                       // 74
      selector = {};                                                                                                  // 74
      if (!(foreign_key = has_many.foreign_key)) {                                                                    // 76
        foreign_key = (_.singularize(this.constructor.to_s().toLowerCase())) + "_id";                                 // 78
      }                                                                                                               //
      if (this.constructor._object_id) {                                                                              // 79
        selector[foreign_key] = new Meteor.Collection.ObjectID(this.id);                                              // 80
      } else {                                                                                                        //
        selector[foreign_key] = this.id;                                                                              // 82
      }                                                                                                               //
      class_name = has_many.class_name || _.titleize(_.singularize(relation));                                        // 74
      this[relation] = (function(relation, selector, class_name) {                                                    // 74
        return function(mod_selector, options) {                                                                      //
          if (mod_selector == null) {                                                                                 //
            mod_selector = {};                                                                                        //
          }                                                                                                           //
          if (options == null) {                                                                                      //
            options = {};                                                                                             //
          }                                                                                                           //
          mod_selector = _.extend(mod_selector, selector);                                                            // 88
          if (global[class_name]) {                                                                                   // 90
            return HasManyRelation.fromRelation(global[class_name].where(mod_selector, options), foreign_key, this.id);
          }                                                                                                           //
        };                                                                                                            //
      })(relation, selector, class_name);                                                                             //
    }                                                                                                                 // 73
    ref5 = this.constructor.has_one;                                                                                  // 94
    for (o = 0, len4 = ref5.length; o < len4; o++) {                                                                  // 94
      has_one = ref5[o];                                                                                              //
      relation = has_one.name;                                                                                        // 95
      selector = {};                                                                                                  // 95
      if (!(foreign_key = has_one.foreign_key)) {                                                                     // 97
        foreign_key = (_.singularize(this.constructor.to_s().toLowerCase())) + "_id";                                 // 98
      }                                                                                                               //
      if (this.constructor._object_id) {                                                                              // 99
        selector[foreign_key] = new Meteor.Collection.ObjectID(this.id);                                              // 100
      } else {                                                                                                        //
        selector[foreign_key] = this.id;                                                                              // 102
      }                                                                                                               //
      class_name = has_one.class_name || _.titleize(relation);                                                        // 95
      this[relation] = (function(relation, selector, class_name) {                                                    // 95
        return function(mod_selector, options) {                                                                      //
          if (mod_selector == null) {                                                                                 //
            mod_selector = {};                                                                                        //
          }                                                                                                           //
          if (options == null) {                                                                                      //
            options = {};                                                                                             //
          }                                                                                                           //
          mod_selector = _.extend(mod_selector, selector);                                                            // 108
          if (global[class_name]) {                                                                                   // 110
            return global[class_name].first(mod_selector, options);                                                   //
          }                                                                                                           //
        };                                                                                                            //
      })(relation, selector, class_name);                                                                             //
    }                                                                                                                 // 94
    ref6 = this.constructor.has_and_belongs_to_many;                                                                  // 115
    results = [];                                                                                                     // 115
    for (p = 0, len5 = ref6.length; p < len5; p++) {                                                                  //
      habtm = ref6[p];                                                                                                //
      relation = habtm.name;                                                                                          // 116
      identifier = (_.singularize(relation)) + "_ids";                                                                // 116
      class_name = habtm.class_name || _.titleize(_.singularize(relation));                                           // 116
      results.push(this[relation] = (function(relation, identifier, class_name) {                                     // 116
        return function(mod_selector, options) {                                                                      //
          var filter, instance, inverse, inverse_identifier;                                                          // 122
          if (mod_selector == null) {                                                                                 //
            mod_selector = {};                                                                                        //
          }                                                                                                           //
          if (options == null) {                                                                                      //
            options = {};                                                                                             //
          }                                                                                                           //
          selector = {                                                                                                // 122
            _id: {                                                                                                    // 122
              $in: self[identifier]                                                                                   // 122
            }                                                                                                         //
          };                                                                                                          //
          mod_selector = _.extend(mod_selector, selector);                                                            // 122
          instance = global[class_name].init();                                                                       // 122
          filter = function(r) {                                                                                      // 122
            name = r.class_name || _.titleize(_.singularize(r.name));                                                 // 127
            return global[name] === this.constructor;                                                                 //
          };                                                                                                          //
          inverse = _.find(instance.constructor.has_and_belongs_to_many, filter, this);                               // 122
          inverse_identifier = (_.singularize(inverse.name)) + "_ids";                                                // 122
          if (global[class_name] && self[identifier] && self[identifier].length) {                                    // 131
            relation = global[class_name].where(mod_selector, options);                                               // 132
            return HasAndBelongsToManyRelation.fromRelation(relation, this, inverse_identifier, identifier, this.id);
          } else {                                                                                                    //
            return HasAndBelongsToManyRelation["new"](this, global[class_name], inverse_identifier, identifier, this.id);
          }                                                                                                           //
        };                                                                                                            //
      })(relation, identifier, class_name));                                                                          //
    }                                                                                                                 // 115
    return results;                                                                                                   //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.r = function(relation) {                                                                      // 5
    return this.related(relation);                                                                                    //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.related = function(relation, options) {                                                       // 5
    var belongs_to, foreign_key, habtm, has_many, identifier, j, l, len, len1, len2, m, ref, ref1, ref2, selector;    // 152
    if (options == null) {                                                                                            //
      options = {};                                                                                                   //
    }                                                                                                                 //
    ref = this.constructor.belongs_to;                                                                                // 152
    for (j = 0, len = ref.length; j < len; j++) {                                                                     // 152
      belongs_to = ref[j];                                                                                            //
      if (relation === belongs_to.name) {                                                                             // 153
        identifier = belongs_to.name + "_id";                                                                         // 154
        if (!belongs_to.class_name) {                                                                                 // 156
          belongs_to.class_name = _.titleize(belongs_to.name);                                                        // 157
        }                                                                                                             //
        if (this[identifier]) {                                                                                       // 159
          return global[belongs_to.class_name].find(this[identifier], options);                                       // 160
        } else {                                                                                                      //
          return false;                                                                                               // 162
        }                                                                                                             //
      }                                                                                                               //
    }                                                                                                                 // 152
    ref1 = this.constructor.has_many;                                                                                 // 164
    for (l = 0, len1 = ref1.length; l < len1; l++) {                                                                  // 164
      has_many = ref1[l];                                                                                             //
      if (relation === has_many.name) {                                                                               // 165
        selector = {};                                                                                                // 166
        if (!(foreign_key = has_many.foreign_key)) {                                                                  // 167
          foreign_key = (_.singularize(this.constructor.to_s().toLowerCase())) + "_id";                               // 169
        }                                                                                                             //
        if (this.constructor._object_id) {                                                                            // 170
          selector[foreign_key] = new Meteor.Collection.ObjectID(this.id);                                            // 171
        } else {                                                                                                      //
          selector[foreign_key] = this.id;                                                                            // 173
        }                                                                                                             //
        if (!has_many.class_name) {                                                                                   // 175
          has_many.class_name = _.titleize(_.singularize(has_many.name));                                             // 176
        }                                                                                                             //
        return global[has_many.class_name].where(selector, options);                                                  // 178
      }                                                                                                               //
    }                                                                                                                 // 164
    ref2 = this.constructor.has_and_belongs_to_many;                                                                  // 180
    for (m = 0, len2 = ref2.length; m < len2; m++) {                                                                  // 180
      habtm = ref2[m];                                                                                                //
      if (relation === habtm.name) {                                                                                  // 181
        identifier = (_.singularize(habtm.name)) + "_ids";                                                            // 182
        if (!habtm.class_name) {                                                                                      // 184
          habtm.class_name = _.titleize(_.singularize(habtm.name));                                                   // 185
        }                                                                                                             //
        if (this[identifier] && this[identifier].length) {                                                            // 186
          return global[habtm.class_name].where({                                                                     // 187
            _id: {                                                                                                    // 187
              $in: this[identifier]                                                                                   // 187
            }                                                                                                         //
          }, options);                                                                                                //
        } else {                                                                                                      //
          return [];                                                                                                  // 189
        }                                                                                                             //
      }                                                                                                               //
    }                                                                                                                 // 180
    return console.warn("Method " + relation + " does not exist for " + (this.constructor.to_s()) + ".");             //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.error = function(field, message) {                                                            // 5
    var obj;                                                                                                          // 201
    this.errors || (this.errors = []);                                                                                // 201
    obj = {};                                                                                                         // 201
    obj[field] = message;                                                                                             // 201
    return this.errors.push(obj);                                                                                     //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.isValid = function(attr) {                                                                    // 5
    if (attr == null) {                                                                                               //
      attr = {};                                                                                                      //
    }                                                                                                                 //
    this.validate();                                                                                                  // 207
    return !this.errors;                                                                                              //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.validate = function() {                                                                       // 5
    return true;                                                                                                      //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.is_new = function() {                                                                         // 5
    return this.isNew();                                                                                              //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.isNew = function() {                                                                          // 5
    return this.__is_new;                                                                                             //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.save = function(attr, callback) {                                                             // 5
    var k, v;                                                                                                         // 220
    if (attr == null) {                                                                                               //
      attr = {};                                                                                                      //
    }                                                                                                                 //
    if (callback == null) {                                                                                           //
      callback = void 0;                                                                                              //
    }                                                                                                                 //
    this.errors = false;                                                                                              // 220
    for (k in attr) {                                                                                                 // 222
      v = attr[k];                                                                                                    //
      this[k] = v;                                                                                                    // 223
    }                                                                                                                 // 222
    if (this.constructor.before_save) {                                                                               // 225
      attr = this.constructor.before_save(attr);                                                                      // 225
    }                                                                                                                 //
    if (!this.isValid()) {                                                                                            // 227
      return this;                                                                                                    // 227
    }                                                                                                                 //
    if (callback != null) {                                                                                           // 231
      if (this.isNew()) {                                                                                             // 232
        this.constructor._collection.insert(attr, ((function(_this) {                                                 // 233
          return function(error, result) {                                                                            //
            if (error == null) {                                                                                      // 234
              _this.id = _this._id = result;                                                                          // 235
              _this.__is_new = false;                                                                                 // 235
              if (_this.constructor.after_save) {                                                                     // 238
                _this.constructor.after_save(_this);                                                                  // 239
              }                                                                                                       //
            }                                                                                                         //
            return callback(error, result);                                                                           //
          };                                                                                                          //
        })(this)));                                                                                                   //
      } else {                                                                                                        //
        this.constructor._collection.update(this.id, {                                                                // 244
          $set: attr                                                                                                  // 244
        }, ((function(_this) {                                                                                        //
          return function(error, result) {                                                                            //
            if (error == null) {                                                                                      // 245
              if (_this.constructor.after_save) {                                                                     // 246
                _this.constructor.after_save(_this);                                                                  // 247
              }                                                                                                       //
            }                                                                                                         //
            return callback(error, result);                                                                           //
          };                                                                                                          //
        })(this)));                                                                                                   //
      }                                                                                                               //
      return null;                                                                                                    // 252
    } else {                                                                                                          //
      if (this.isNew()) {                                                                                             // 255
        this.id = this._id = this.constructor._collection.insert(attr);                                               // 256
        this.__is_new = false;                                                                                        // 256
      } else {                                                                                                        //
        this.constructor._collection.update(this.id, {                                                                // 259
          $set: attr                                                                                                  // 259
        });                                                                                                           //
      }                                                                                                               //
      if (this.constructor.after_save) {                                                                              // 261
        this.constructor.after_save(this);                                                                            // 262
      }                                                                                                               //
      return this;                                                                                                    // 264
    }                                                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.update = function(attr, callback) {                                                           // 5
    if (callback == null) {                                                                                           //
      callback = void 0;                                                                                              //
    }                                                                                                                 //
    return this.save(attr, callback);                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.push = function(data) {                                                                       // 5
    return this.constructor._collection.update(this.id, {                                                             //
      $addToSet: data                                                                                                 // 277
    });                                                                                                               //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.pull = function(data) {                                                                       // 5
    return this.constructor._collection.update(this.id, {                                                             //
      $pull: data                                                                                                     // 281
    });                                                                                                               //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.del = function(field) {                                                                       // 5
    var unset;                                                                                                        // 284
    unset = {};                                                                                                       // 284
    unset[field] = "";                                                                                                // 284
    return this.constructor._collection.update(this.id, {                                                             //
      $unset: unset                                                                                                   // 286
    });                                                                                                               //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.destroy = function(callback) {                                                                // 5
    if (callback == null) {                                                                                           //
      callback = void 0;                                                                                              //
    }                                                                                                                 //
    if (this.id != null) {                                                                                            // 289
      this.constructor._collection.remove(this.id, callback);                                                         // 290
      return this.id = this._id = null;                                                                               //
    }                                                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.prototype.reload = function() {                                                                         // 5
    if (this.id != null) {                                                                                            // 294
      return this.constructor.find(this.id);                                                                          //
    }                                                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid._object_id = false;                                                                                     // 5
                                                                                                                      //
  Minimongoid._collection = void 0;                                                                                   // 5
                                                                                                                      //
  Minimongoid._type = void 0;                                                                                         // 5
                                                                                                                      //
  Minimongoid._debug = false;                                                                                         // 5
                                                                                                                      //
  Minimongoid.defaults = [];                                                                                          // 5
                                                                                                                      //
  Minimongoid.belongs_to = [];                                                                                        // 5
                                                                                                                      //
  Minimongoid.has_many = [];                                                                                          // 5
                                                                                                                      //
  Minimongoid.has_one = [];                                                                                           // 5
                                                                                                                      //
  Minimongoid.has_and_belongs_to_many = [];                                                                           // 5
                                                                                                                      //
  Minimongoid.embedded_in = null;                                                                                     // 5
                                                                                                                      //
  Minimongoid.embeds_many = [];                                                                                       // 5
                                                                                                                      //
  Minimongoid.init = function(attr, parent, is_new) {                                                                 // 5
    if (parent == null) {                                                                                             //
      parent = null;                                                                                                  //
    }                                                                                                                 //
    if (is_new == null) {                                                                                             //
      is_new = false;                                                                                                 //
    }                                                                                                                 //
    return new this(attr, parent, is_new);                                                                            //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.to_s = function() {                                                                                     // 5
    if (this._collection) {                                                                                           // 324
      return this._collection._name;                                                                                  //
    } else {                                                                                                          //
      return "embedded";                                                                                              //
    }                                                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.create = function(attr, callback) {                                                                     // 5
    var doc;                                                                                                          // 327
    if (callback == null) {                                                                                           //
      callback = void 0;                                                                                              //
    }                                                                                                                 //
    attr.createdAt || (attr.createdAt = new Date());                                                                  // 327
    if (this.before_create) {                                                                                         // 328
      attr = this.before_create(attr);                                                                                // 328
    }                                                                                                                 //
    doc = this.init(attr, null, true);                                                                                // 327
    if (callback != null) {                                                                                           // 331
      doc.save(attr, callback);                                                                                       // 332
      return null;                                                                                                    //
    } else {                                                                                                          //
      doc = doc.save(attr);                                                                                           // 335
      doc.initAttrsAndRelations(attr);                                                                                // 335
      if (doc && this.after_create) {                                                                                 // 337
        return this.after_create(doc);                                                                                //
      } else {                                                                                                        //
        return doc;                                                                                                   //
      }                                                                                                               //
    }                                                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.where = function(selector, options) {                                                                   // 5
    var result, self;                                                                                                 // 344
    if (selector == null) {                                                                                           //
      selector = {};                                                                                                  //
    }                                                                                                                 //
    if (options == null) {                                                                                            //
      options = {};                                                                                                   //
    }                                                                                                                 //
    self = this;                                                                                                      // 344
    if (this._debug) {                                                                                                // 345
      console.info(" --- WHERE ---");                                                                                 // 346
      console.info("  " + (_.singularize(_.classify(this.to_s()))) + ".where(" + (JSON.stringify(selector)) + (!_.isEmpty(options) ? ',' + JSON.stringify(options) : '') + ")");
    }                                                                                                                 //
    result = this.find(selector, options).fetch();                                                                    // 344
    result = Relation["new"].apply(Relation, [self].concat(slice.call(result)));                                      // 344
    result.setQuery(selector);                                                                                        // 344
    if (this._debug && result) {                                                                                      // 351
      console.info("  > found " + result.length);                                                                     // 351
    }                                                                                                                 //
    return result;                                                                                                    //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.first = function(selector, options) {                                                                   // 5
    var doc;                                                                                                          // 355
    if (selector == null) {                                                                                           //
      selector = {};                                                                                                  //
    }                                                                                                                 //
    if (options == null) {                                                                                            //
      options = {};                                                                                                   //
    }                                                                                                                 //
    if (this._debug) {                                                                                                // 355
      console.info(" --- FIRST ---");                                                                                 // 356
      console.info("  " + (_.singularize(_.classify(this.to_s()))) + ".first(" + (JSON.stringify(selector)) + (!_.isEmpty(options) ? ',' + JSON.stringify(options) : '') + ")");
    }                                                                                                                 //
    if (doc = this._collection.findOne(selector, options)) {                                                          // 358
      return this.init(doc);                                                                                          //
    }                                                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.last = function(selector, options) {                                                                    // 5
    var doc;                                                                                                          // 363
    if (selector == null) {                                                                                           //
      selector = {};                                                                                                  //
    }                                                                                                                 //
    if (options == null) {                                                                                            //
      options = {};                                                                                                   //
    }                                                                                                                 //
    options.sort = {                                                                                                  // 363
      createdAt: -1                                                                                                   // 363
    };                                                                                                                //
    if (doc = this._collection.findOne(selector, options)) {                                                          // 364
      return this.init(doc);                                                                                          //
    }                                                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.all = function(options) {                                                                               // 5
    if (options == null) {                                                                                            //
      options = {};                                                                                                   //
    }                                                                                                                 //
    return this.where({}, options);                                                                                   //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.find = function(selector, options) {                                                                    // 5
    var self;                                                                                                         // 372
    if (selector == null) {                                                                                           //
      selector = {};                                                                                                  //
    }                                                                                                                 //
    if (options == null) {                                                                                            //
      options = {};                                                                                                   //
    }                                                                                                                 //
    self = this;                                                                                                      // 372
    if (!options.transform) {                                                                                         // 374
      options.transform = function(doc) {                                                                             // 375
        return self.init(doc);                                                                                        //
      };                                                                                                              //
    }                                                                                                                 //
    if (typeof selector !== 'object') {                                                                               // 378
      if (this._object_id) {                                                                                          // 379
        selector = new Meteor.Collection.ObjectID(selector);                                                          // 380
      }                                                                                                               //
      return this.first({                                                                                             //
        _id: selector                                                                                                 // 381
      }, options);                                                                                                    //
    } else if (selector instanceof Meteor.Collection.ObjectID) {                                                      //
      return this.first({                                                                                             //
        _id: selector                                                                                                 // 383
      }, options);                                                                                                    //
    } else {                                                                                                          //
      if (this._object_id) {                                                                                          // 386
        if (selector && selector._id) {                                                                               // 387
          if (typeof selector._id === 'string') {                                                                     // 388
            selector._id = new Meteor.Collection.ObjectID(selector._id);                                              // 389
          } else if (selector._id['$in']) {                                                                           //
            selector._id['$in'] = _.map_object_id(selector._id['$in']);                                               // 392
          }                                                                                                           //
        }                                                                                                             //
        if (selector && selector._ids) {                                                                              // 393
          selector._ids = _.map(selector._ids, function(id) {                                                         // 394
            return new Meteor.Collection.ObjectID(id);                                                                //
          });                                                                                                         //
        }                                                                                                             //
      }                                                                                                               //
      return this._collection.find(selector, options);                                                                //
    }                                                                                                                 //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.count = function(selector, options) {                                                                   // 5
    if (selector == null) {                                                                                           //
      selector = {};                                                                                                  //
    }                                                                                                                 //
    if (options == null) {                                                                                            //
      options = {};                                                                                                   //
    }                                                                                                                 //
    return this.find(selector, options).count();                                                                      //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.destroyAll = function(selector) {                                                                       // 5
    if (selector == null) {                                                                                           //
      selector = {};                                                                                                  //
    }                                                                                                                 //
    return this._collection.remove(selector);                                                                         //
  };                                                                                                                  //
                                                                                                                      //
  Minimongoid.modelize = function(cursor, parent) {                                                                   // 5
    var models, self;                                                                                                 // 409
    if (parent == null) {                                                                                             //
      parent = null;                                                                                                  //
    }                                                                                                                 //
    self = this;                                                                                                      // 409
    models = cursor.map(function(i) {                                                                                 // 409
      return self.init(i, parent);                                                                                    //
    });                                                                                                               //
    return Relation["new"].apply(Relation, [self].concat(slice.call(models)));                                        //
  };                                                                                                                  //
                                                                                                                      //
  return Minimongoid;                                                                                                 //
                                                                                                                      //
})();                                                                                                                 //
                                                                                                                      //
_.singularize = function(s) {                                                                                         // 1
  return s = s.replace(/s$/, "");                                                                                     //
};                                                                                                                    // 416
                                                                                                                      //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['kaptron:minimongoid'] = {};

})();

//# sourceMappingURL=kaptron_minimongoid.js.map
