(function(){Blog.config({
  adminRole: 'admin'
});

}).call(this);
